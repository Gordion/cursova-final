import React from "react";

const Footer = () => (
  <div className="footer">
    <p>All rights reserved. 2022</p>
  </div>
);

export default Footer;
